const express = require('express');
const router = express.Router();
const {addUser, getUserList} = require('../controller/UserController');

router.get('/list',getUserList);
router.post('/new',addUser);

module.exports = router;