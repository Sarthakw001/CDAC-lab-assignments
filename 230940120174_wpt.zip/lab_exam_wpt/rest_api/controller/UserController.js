let users = [];
let counter = 0;

exports.addUser = (req, res) => {
  try {
    const { username, gender, dateOfBirth } = req.body;

    if (!username || !gender || !dateOfBirth) {
      res.status(400).send("all fields required");
    }

    const user = {
      id: ++counter,
      username,
      gender,
      dateOfBirth,
    };

    users.push(user);

    res.status(201).json(user);
  } catch (error) {
    console.log(error.message);
  }
};

exports.getUserList = (req, res) => {
  try {
    res.status(201).json(users);
  } catch (error) {
    console.log(error.message);
  }
};
