import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import UserForm from "./components/UserForm";
import UserList from "./components/UserList";

function App() {
  return (
    <>
      <UserForm />
      <br />
      <br />
      <br />
      <UserList />
    </>
  );
}

export default App;
