import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserList = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:8080/list');
        setUsers(response.data);
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };

    fetchUsers();
  }, [users]);

  return (
    <div>
      <h2>Users List</h2>
      <table className="table" style={{border:"1px solid black"}}>
        <thead>
          <tr>
            <th>Username</th>
            <th>Gender</th>
            <th>Date of Birth</th>
          </tr>
        </thead>
        <tbody >
          {users.map((event) => (
            <tr key={event.id} >
              <td style={{border:"1px solid black"}}>{event.username}</td>
              <td style={{border:"1px solid black"}}>{event.gender}</td>
              <td style={{border:"1px solid black"}}>{event.dateOfBirth}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserList;
