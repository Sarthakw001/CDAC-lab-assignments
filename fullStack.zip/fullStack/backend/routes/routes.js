// routes/eventRoutes.js

const express = require('express');
const router = express.Router();
const eventController = require('../controller/eventController');

// GET all events
router.get('/getEvent', eventController.getAllEvents);

// POST new event
router.post('/createEvent', eventController.createEvent);

module.exports = router;
