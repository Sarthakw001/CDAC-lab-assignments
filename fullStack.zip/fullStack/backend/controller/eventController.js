// controllers/eventController.js

let events = [];

const getAllEvents = (req, res) => {
  res.json(events);
};

const createEvent = (req, res) => {
  const { title, description, dueDate } = req.body;

  if (!title || !description || !dueDate) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const newEvent = {
    id: events.length + 1,
    title,
    description,
    dueDate,
  };

  events.push(newEvent);
  res.status(201).json(newEvent);
};

module.exports = {
  getAllEvents,
  createEvent,
};
