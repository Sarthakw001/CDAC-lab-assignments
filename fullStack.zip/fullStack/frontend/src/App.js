// src/App.js

import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import CreateEvent from "./components/CreateEventForm";
import EventList from "./components/EventList";

function App() {
  return (
    <>
      <CreateEvent />
      <br />
      <br />
      <br />
      <EventList />
    </>
  );
}

export default App;
