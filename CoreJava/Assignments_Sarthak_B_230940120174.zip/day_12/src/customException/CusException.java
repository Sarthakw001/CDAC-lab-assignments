package customException;

public class CusException extends Exception {
    public CusException(String msg) {
        super(msg);
    }
}
