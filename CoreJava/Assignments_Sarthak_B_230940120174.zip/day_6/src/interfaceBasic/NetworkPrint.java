package interfaceBasic;

public class NetworkPrint implements Printer {
    public void print(){
        System.out.println("Hello from Network print");
    }
}
