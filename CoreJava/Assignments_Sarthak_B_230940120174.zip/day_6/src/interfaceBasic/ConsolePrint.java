package interfaceBasic;

public class ConsolePrint implements Printer {
    public void print(){
        System.out.println("Hello from console print");
    }
}
