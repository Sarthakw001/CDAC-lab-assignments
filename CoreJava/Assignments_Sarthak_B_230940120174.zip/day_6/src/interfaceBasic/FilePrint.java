package interfaceBasic;

public class FilePrint implements Printer {
    public void print(){
        System.out.println("Hello from File print");
    }
}
