package interfaceBasic;

public interface Printer {
    int speeed = 100;
    void print();
}