package core;

public interface Stack {
    int STACK_SIZE = 10;

    void push(Customer c);

    void pop();
}